package models;

public class Primario extends Personale {

	public Primario(String nome, String cognome, String codiceDiIdentificazione, User autentificazione) {
		super(nome, cognome, codiceDiIdentificazione, autentificazione);
		// TODO Auto-generated constructor stub
	}
	
}