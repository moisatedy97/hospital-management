package models;

public class Medico extends Personale {

	public Medico(String nome, String cognome, String codiceDiIdentificazione, User autentificazione) {
		super(nome, cognome, codiceDiIdentificazione, autentificazione);
	}
}
