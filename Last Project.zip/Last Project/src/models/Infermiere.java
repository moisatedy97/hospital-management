package models;

public class Infermiere extends Personale {

	public Infermiere(String nome, String cognome, String codiceDiIdentificazione, User autentificazione) {
		super(nome, cognome, codiceDiIdentificazione, autentificazione);
		// TODO Auto-generated constructor stub
	}
	
}
